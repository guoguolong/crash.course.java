package club.banyuan.springsession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
